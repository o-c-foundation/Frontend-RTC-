declare module 'react' {
  export * from 'react';
}

declare module 'react-dom/client' {
  export * from 'react-dom/client';
}

declare module 'react/jsx-runtime' {
  export * from 'react/jsx-runtime';
}
